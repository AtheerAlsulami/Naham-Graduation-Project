const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb');

const ddb = new DynamoDBClient({});
const DISHES_TABLE = process.env.DISHES_TABLE;
const DISHES_BUCKET = String(process.env.DISHES_BUCKET || '').trim();
const DISHES_PUBLIC_BASE_URL = String(
  process.env.DISHES_PUBLIC_BASE_URL || '',
).trim();
const AWS_REGION =
  process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || 'eu-north-1';
const SIGNED_IMAGE_TTL_SECONDS = (() => {
  const parsed = Number(process.env.DISH_IMAGE_SIGNED_URL_TTL_SECONDS);
  if (!Number.isFinite(parsed) || parsed <= 0) return 60 * 60;
  return Math.min(Math.trunc(parsed), 12 * 60 * 60);
})();
const SCAN_PAGE_LIMIT = (() => {
  const parsed = Number(process.env.DISHES_SCAN_PAGE_LIMIT);
  if (!Number.isFinite(parsed) || parsed <= 0) return 120;
  return Math.min(Math.trunc(parsed), 1000);
})();
const SCAN_MAX_PAGES = (() => {
  const parsed = Number(process.env.DISHES_SCAN_MAX_PAGES);
  if (!Number.isFinite(parsed) || parsed <= 0) return 40;
  return Math.min(Math.trunc(parsed), 500);
})();

let s3 = null;
let GetObjectCommandCtor = null;
let getSignedUrlFn = null;
try {
  const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
  const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
  s3 = new S3Client({ region: AWS_REGION });
  GetObjectCommandCtor = GetObjectCommand;
  getSignedUrlFn = getSignedUrl;
} catch (error) {
  console.warn(
    'dishesList optional S3 signing disabled:',
    error?.message || 'Unknown error',
  );
}
const ENV_FALLBACK_TABLES = String(process.env.DISHES_FALLBACK_TABLES || '')
  .split(',')
  .map((table) => table.trim())
  .filter(Boolean);
const DEFAULT_FALLBACK_TABLES = ['cook_dishes', 'naham_dishes', 'dishes'];
const FALLBACK_TABLES = Array.from(
  new Set([...ENV_FALLBACK_TABLES, ...DEFAULT_FALLBACK_TABLES]),
);
const JSON_HEADERS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'OPTIONS,GET',
};

function response(statusCode, payload) {
  return {
    statusCode,
    headers: JSON_HEADERS,
    body: JSON.stringify(payload),
  };
}

function pickString(attrValue, fallback = '') {
  return typeof attrValue?.S === 'string' ? attrValue.S : fallback;
}

function pickNumber(attrValue, fallback = 0) {
  if (typeof attrValue?.N !== 'string') {
    return fallback;
  }
  const parsed = Number(attrValue.N);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function pickBoolean(attrValue, fallback = false) {
  if (typeof attrValue?.BOOL === 'boolean') {
    return attrValue.BOOL;
  }
  return fallback;
}

function pickStringList(attrValue) {
  if (Array.isArray(attrValue?.L)) {
    return attrValue.L
      .map((entry) => (typeof entry?.S === 'string' ? entry.S.trim() : ''))
      .filter(Boolean);
  }
  if (typeof attrValue?.S === 'string') {
    const raw = attrValue.S.trim();
    if (!raw) return [];
    try {
      const decoded = JSON.parse(raw);
      if (Array.isArray(decoded)) {
        return decoded
          .map((item) => String(item || '').trim())
          .filter(Boolean);
      }
    } catch (_) {
      // ignore malformed data
    }
  }
  return [];
}

function mapItemToDish(item) {
  return {
    id: pickString(item.id),
    cookId: pickString(item.cookId),
    cookName: pickString(item.cookName, '@cook'),
    name: pickString(item.name),
    description: pickString(item.description),
    price: pickNumber(item.price, 0),
    imageUrl: pickString(item.imageUrl),
    imageKey: pickString(item.imageKey),
    rating: pickNumber(item.rating, 0),
    reviewsCount: Math.round(pickNumber(item.reviewsCount, 0)),
    categoryId: pickString(item.categoryId),
    ingredients: pickStringList(item.ingredients),
    isAvailable: pickBoolean(item.isAvailable, true),
    preparationTimeMin: Math.round(pickNumber(item.preparationTimeMin, 30)),
    preparationTimeMax: Math.round(pickNumber(item.preparationTimeMax, 45)),
    createdAt: pickString(item.createdAt, new Date().toISOString()),
  };
}

function stripLeadingSlash(value) {
  return String(value || '').replace(/^\/+/, '');
}

function isAlreadySigned(url) {
  return /[?&]X-Amz-Signature=/i.test(url);
}

function hasHttpScheme(value) {
  return /^https?:\/\//i.test(String(value || '').trim());
}

function parseConfiguredPublicHost() {
  if (!DISHES_PUBLIC_BASE_URL) return '';
  try {
    return new URL(DISHES_PUBLIC_BASE_URL).hostname.toLowerCase();
  } catch (_) {
    return '';
  }
}

const CONFIGURED_PUBLIC_HOST = parseConfiguredPublicHost();

function extractS3Location(dish) {
  const imageKey = stripLeadingSlash(String(dish?.imageKey || '').trim());
  if (imageKey && DISHES_BUCKET) {
    return { bucket: DISHES_BUCKET, key: imageKey };
  }

  const raw = String(dish?.imageUrl || '').trim();
  if (!raw) return null;
  if (isAlreadySigned(raw)) return null;

  if (!hasHttpScheme(raw) && DISHES_BUCKET) {
    return {
      bucket: DISHES_BUCKET,
      key: stripLeadingSlash(raw),
    };
  }

  if (/^s3:\/\//i.test(raw)) {
    const withoutScheme = raw.replace(/^s3:\/\//i, '');
    const [bucket, ...keyParts] = withoutScheme.split('/').filter(Boolean);
    const key = keyParts.join('/');
    if (bucket && key) {
      return { bucket, key };
    }
  }

  try {
    const parsed = new URL(raw);
    const host = parsed.hostname.toLowerCase();
    const path = stripLeadingSlash(decodeURIComponent(parsed.pathname));
    if (!path) return null;

    // Virtual-hosted-style URL:
    // https://<bucket>.s3.<region>.amazonaws.com/<key>
    // https://<bucket>.s3.amazonaws.com/<key>
    const virtualHostMatch = host.match(
      /^(.+)\.s3(?:[.-][a-z0-9-]+)?\.amazonaws\.com$/i,
    );
    if (virtualHostMatch && virtualHostMatch[1]) {
      return {
        bucket: virtualHostMatch[1],
        key: path,
      };
    }

    // Path-style URL:
    // https://s3.<region>.amazonaws.com/<bucket>/<key>
    // https://s3.amazonaws.com/<bucket>/<key>
    if (/^s3(?:[.-][a-z0-9-]+)?\.amazonaws\.com$/i.test(host)) {
      const segments = path.split('/').filter(Boolean);
      if (segments.length >= 2) {
        const [bucket, ...keyParts] = segments;
        const key = keyParts.join('/');
        if (bucket && key) {
          return { bucket, key };
        }
      }
    }

    // Fallback when bucket is configured and URL host belongs to it.
    if (DISHES_BUCKET) {
      const configuredBucket = DISHES_BUCKET.toLowerCase();
      const isConfiguredBucketHost =
        host === `${configuredBucket}.s3.${AWS_REGION}`.toLowerCase() ||
        host === `${configuredBucket}.s3.${AWS_REGION}.amazonaws.com`.toLowerCase() ||
        host === `${configuredBucket}.s3.amazonaws.com` ||
        host.startsWith(`${configuredBucket}.s3.`);
      if (isConfiguredBucketHost) {
        return {
          bucket: DISHES_BUCKET,
          key: path,
        };
      }

      // Support custom public domains (for example CloudFront/custom CNAME)
      // by resolving key from URL path and signing using the configured bucket.
      if (CONFIGURED_PUBLIC_HOST && host === CONFIGURED_PUBLIC_HOST) {
        return {
          bucket: DISHES_BUCKET,
          key: path,
        };
      }
    }

    return null;
  } catch (_) {
    return null;
  }
}

async function withSignedImageUrl(dish) {
  if (!s3 || !GetObjectCommandCtor || !getSignedUrlFn) return dish;
  const location = extractS3Location(dish);
  if (!location) return dish;

  try {
    const imageUrl = await getSignedUrlFn(
      s3,
      new GetObjectCommandCtor({
        Bucket: location.bucket,
        Key: location.key,
      }),
      { expiresIn: SIGNED_IMAGE_TTL_SECONDS },
    );
    return { ...dish, imageUrl };
  } catch (error) {
    console.warn('dishesList sign-image-url failed', {
      dishId: dish.id,
      bucket: location.bucket,
      key: location.key,
      error: error?.message || 'Unknown error',
    });
    return dish;
  }
}

async function withSignedImageUrls(dishes) {
  if (!Array.isArray(dishes) || dishes.length === 0) return [];
  return Promise.all(dishes.map(withSignedImageUrl));
}

async function scanAllItemsFromTable(tableName) {
  let lastEvaluatedKey;
  const results = [];
  let pageCount = 0;
  do {
    pageCount += 1;
    const scanResult = await ddb.send(
      new ScanCommand({
        TableName: tableName,
        ExclusiveStartKey: lastEvaluatedKey,
        Limit: SCAN_PAGE_LIMIT,
      }),
    );
    results.push(...(scanResult.Items ?? []));
    lastEvaluatedKey = scanResult.LastEvaluatedKey;
    if (pageCount >= SCAN_MAX_PAGES) {
      break;
    }
  } while (lastEvaluatedKey);
  return results;
}

async function loadDishesRaw() {
  const tableNames = Array.from(
    new Set([DISHES_TABLE, ...FALLBACK_TABLES].filter(Boolean)),
  );
  let lastError = null;

  for (const tableName of tableNames) {
    try {
      return await scanAllItemsFromTable(tableName);
    } catch (error) {
      const code = String(error?.name || '').toLowerCase();
      if (code.includes('resourcenotfound')) {
        lastError = error;
        continue;
      }
      throw error;
    }
  }

  if (lastError) {
    throw lastError;
  }
  return [];
}

function parseBool(value, fallback = null) {
  if (value == null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const normalized = String(value).trim().toLowerCase();
  if (normalized === 'true' || normalized === '1') return true;
  if (normalized === 'false' || normalized === '0') return false;
  return fallback;
}

function parseLimit(value, fallback = 100, max = 500) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.min(Math.trunc(parsed), max);
}

exports.handler = async (event) => {
  if (event?.requestContext?.http?.method === 'OPTIONS') {
    return response(200, { ok: true });
  }

  if (!DISHES_TABLE) {
    return response(500, {
      message: 'Server misconfiguration: DISHES_TABLE is not set.',
    });
  }

  try {
    const query = event?.queryStringParameters || {};
    const dishId = (event?.pathParameters?.id || query.id || '').toString().trim();
    const cookId = (query.cookId || '').toString().trim();
    const categoryId = (query.categoryId || '').toString().trim();
    const onlyAvailable = parseBool(query.onlyAvailable, null);
    const sort = (query.sort || 'newest').toString().trim().toLowerCase();
    const newestFirst = sort !== 'oldest';
    const limit = parseLimit(query.limit, 120, 500);

    const rawItems = await loadDishesRaw();
    let dishes = rawItems.map(mapItemToDish);

    if (dishId) {
      const dish = dishes.find((item) => item.id === dishId);
      if (!dish) {
        return response(404, { message: 'Dish not found.', id: dishId });
      }
      const [signedDish] = await withSignedImageUrls([dish]);
      return response(200, { dish: signedDish });
    }

    if (cookId) {
      dishes = dishes.filter((dish) => dish.cookId === cookId);
    }
    if (categoryId) {
      dishes = dishes.filter((dish) => dish.categoryId === categoryId);
    }
    if (onlyAvailable != null) {
      dishes = dishes.filter((dish) => dish.isAvailable === onlyAvailable);
    }

    dishes.sort((a, b) => {
      if (newestFirst) {
        return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
      }
      return String(a.createdAt || '').localeCompare(String(b.createdAt || ''));
    });

    const signedItems = await withSignedImageUrls(dishes.slice(0, limit));
    return response(200, {
      items: signedItems,
      count: Math.min(dishes.length, limit),
      total: dishes.length,
    });
  } catch (error) {
    console.error('dishesList error:', error);
    return response(500, {
      message: 'Internal server error.',
      error: error.message || 'Unknown error',
    });
  }
};
